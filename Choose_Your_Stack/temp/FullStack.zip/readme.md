1. Front end running guide is inside the frontend stack folder name you downloaded
2. Back end running guide is inside the backtend stack folder name you downloaded
3. The config.json file consits of port number at which the frontend and and backend will be hosted
4. Database connection details