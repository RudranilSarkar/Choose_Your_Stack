GUIDE FOR WINDOWS:


    Prerequisites:
        1. Install node.js for windows

    User Guide:

        1. Go inside "hello-world-example" directory
        2. run the following command to install required node packages

            command: npm install package.json
            
        3. run the following command to start the react app

            command: npm start