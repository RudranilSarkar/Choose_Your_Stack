GUIDE FOR WINDOWS:


    Prerequisites:
    1.Python installed
    2.Flask should be installed
        command: pip install Flask
    3. run the fooowing command:
        command: python <full path to app.py inside "Flask" directory>