GUIDE FOR WINDOWS:


    Prerequisites:

        1.Python installed
        2.Flask should be installed

            command: pip install Flask
        3. important libraries : flask-cors, psycopg2-binary
    
    User guide: 

    1. run the following command to start the server:
    
        command: python <full path to app.py inside "Flask" directory>